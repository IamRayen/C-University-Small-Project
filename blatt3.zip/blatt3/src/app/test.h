#ifndef BLATT3_TEST_H
#define BLATT3_TEST_H


bool testPassed();

bool testObjectIntersection();
bool testMissile();
bool testShip();


#endif //BLATT3_TEST_H
